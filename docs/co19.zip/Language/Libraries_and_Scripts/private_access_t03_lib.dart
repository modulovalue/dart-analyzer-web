// Copyright (c) 2011, the Dart project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE file.


library Libraries_and_Scripts_A05_t03_lib;

class C {
  _foo() {}
  var _bar = 1;
  static var _x = 2;
}

var _topLevelDeclaration = 1;
