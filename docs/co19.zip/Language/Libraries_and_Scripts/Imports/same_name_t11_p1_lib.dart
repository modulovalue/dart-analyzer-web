// Copyright (c) 2011, the Dart project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE file.

library Imports_A03_t21_p1_lib;

import "same_name_t11_p1_lib2.dart";
export "same_name_t11_p1_lib2.dart";
